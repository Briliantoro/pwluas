<?php $__env->startSection('content'); ?>
<div class="clever-catagory blog-details bg-img d-flex align-items-center justify-content-center p-3 height-400" style="background-image: url(<?php echo e(asset('img/bg/pengumuman.png')); ?>);">
    <div class="blog-details-headline">
        <h3><?php echo e($pengumuman->judul); ?></h3>
    </div>
</div>
<!-- ##### Catagory Area End ##### -->

<!-- ##### Blog Details Content ##### -->
<div class="blog-details-content section-padding-100">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-8">
                <!-- Blog Details Text -->
                <div class="blog-details-text">
                    <?php echo $pengumuman->deskripsi; ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app',[
	'title' => 'Detail Pengumuman',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laraschool-master\resources\views/pengumuman/show.blade.php ENDPATH**/ ?>